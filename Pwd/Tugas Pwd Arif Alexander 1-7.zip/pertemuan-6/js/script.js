document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 6 telah dimuat!');
});
