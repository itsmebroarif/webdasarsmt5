document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 4 telah dimuat!');
});
