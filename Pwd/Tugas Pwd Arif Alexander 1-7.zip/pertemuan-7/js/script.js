document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 7 telah dimuat!');
});
