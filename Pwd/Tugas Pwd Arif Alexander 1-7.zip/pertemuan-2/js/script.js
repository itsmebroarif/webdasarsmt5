document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 2 telah dimuat!');
});
