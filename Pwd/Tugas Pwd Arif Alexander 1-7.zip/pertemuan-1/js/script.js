document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 1 telah dimuat!');
});
