document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 5 telah dimuat!');
});
