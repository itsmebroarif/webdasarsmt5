document.addEventListener('DOMContentLoaded', () => {
    console.log('Script untuk Pertemuan 3 telah dimuat!');
});
